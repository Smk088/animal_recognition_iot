<?php
session_start();
include("dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];
if($uname=="")
{
header("location:index.php");
}

$q1=mysqli_query($connect,"select * from ani_data where user='$uname'");

?>
<html>
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>AIRep: AI and IoT based Animal Recognition and Repelling System for Smart Farming</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">	
<!-- bootstrap css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets --> 
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

</head>
<body>
	<!--header section start -->
	<div class="header_section">
		<div class="container">
			<div class="row">
				<div class="col-sm-2">
					<div class="logo"><a href="index.html"><img src="images/logo.png"></a></div>
				</div>
				<div class="col-sm-6">
					<div class="menu-area">
                    <nav class="navbar navbar-expand-lg ">
                        <!-- <a class="navbar-brand" href="#">Menu</a> -->
                        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa fa-bars"></i>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                               <li class="nav-item active">
                                <a class="nav-link" href="userhome.php">Home<span class="sr-only">(current)</span></a> </li>
                               
                               <li class="nav-item">
                                <a class="nav-link" href="logout.php">Logout</a></li>
                               
                            </ul>
                        </div>
                    </nav>
          </div>
				</div>
				<div class="col-sm-4">
            <ul class="top_button_section">
               <!--<li><a class="login-bt active" href="#">Login</a></li>
               <li><a class="login-bt" href="#">Register</a></li>-->
               <li class="search"><a href="#"><img src="images/search-icon.png" alt="#" /></a></li>
            </ul>
					</div>
			</div>

    <div class="row">
      <div class="banner_section layout_padding">
      <section>
         <div id="main_slider" class="section carousel slide banner-main" data-ride="carousel">
            <div class="carousel-inner">
               <div class="carousel-item active">
                    <div class="container">
                     <div class="row marginii">
                        <div class="col-md-5 col-sm-12">
                           <div class="carousel-sporrt_text ">
                             <h1 class="banner_taital">Animal Recognition</h1>
                    <p class="lorem_text">AIRep: AI and IoT based Animal Recognition and Repelling System for Smart Farming</p>
                    <div class="ads_bt"><a href="#">Ads Now</a></div>
                    <div class="contact_bt"><a href="#">Contact Us</a></div>
                           </div>
                        </div>
                        <div class="col-md-7 col-sm-12">
                           <div class="img-box">
                              <figure><img src="images/cow1.jpg" style="max-width: 90%; border:3px solid #009933; border-radius: 25px;"/></figure>
                           </div>
                        </div>
                    </div>
                  </div>
               </div>
               <div class="carousel-item">
                    <div class="container">
                     <div class="row marginii">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                           <div class="carousel-sporrt_text ">
                             <h1 class="banner_taital">Animal Recognition</h1>
                    <p class="lorem_text">AIRep: AI and IoT based Animal Recognition and Repelling System for Smart Farming</p>
                    <div class="ads_bt"><a href="#">Ads Now</a></div>
                    <div class="contact_bt"><a href="#">Contact Us</a></div>
                           </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                           <div class="img-box">
                              <figure><img src="images/banner-img1.png" style="max-width: 100%;"/></figure>
                           </div>
                        </div>
                    </div>
                  </div>
               </div>
               <div class="carousel-item">
                    <div class="container">
                     <div class="row marginii">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                           <div class="carousel-sporrt_text ">
                             <h1 class="banner_taital">Animal Recognition</h1>
                    <p class="lorem_text">AIRep: AI and IoT based Animal Recognition and Repelling System for Smart Farming</p>
                    <div class="ads_bt"><a href="#">Ads Now</a></div>
                    <div class="contact_bt"><a href="#">Contact Us</a></div>
                           </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                           <div class="img-box">
                              <figure><img src="images/banner-img1.png" style="max-width: 100%;"/></figure>
                           </div>
                        </div>
                    </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
    </div>
    </div>

		</div>
        <!--header section end -->
        
		</div>
	</div>
    <!--banner section end -->
	<!--about section start -->
    <div class="about_section layout_padding">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-6">
    				<div class="tablet">
					<div style="border:3px solid #009933; width:500px; height:500px; background-color:#FFFFFF; border-radius: 25px;">
					<h2 align="center">Animal Detected Information</h2>
					
					<div style="height:400px; overflow:auto">
						<?php
						while($r1=mysqli_fetch_array($q1))
						{
						?>
						&nbsp;&nbsp;Animal: <?php echo $r1['animal']; ?>
						<br>&nbsp;&nbsp;Last Detected on : <?php echo $r1['dtime']; ?>
						<div style="border-bottom:#666666 solid 1px">&nbsp;</div>
						<?php
						}
						?>
					</div>
						
					</div>
					
					</div>
    			</div>
    			<div class="col-md-6">
    				<div class="about_taital">
    					<div class="about_text">Welcome to <span style="color: #c6610f;">Farmer</span></div>
    					<p class="dolor_text">Crops in farms are many times damaged by animals 
like buffaloes, cows, goats, birds and wild elephants. This causes 
major losses for the farmers. Farmers can not stay on the field for 
24  hours  and  protect  it.  To  overcome  this  problem,  an  animal 
detection  system  has  been  designed  to  detect  the  presence  of 
animals and it offres a warning and divert the animal without any 
harm.</p>
    					<div class="read_more"><a href="#">Read More</a></div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
    <div class="about_section_2 ">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    				<div class="classified_text">ONE OF THE BEST <span style="color: #c6610f;">CLASSIFIED</span></div>
    			</div>	
    		</div>
    		<div class="row front">
    			<div class="col-md-2">
    				<div class="about_img"><img src="images/img-1.png"></div>
    			</div>
    			<div class="col-md-10">
    				<h1 class="fron_text"> FRONT END MULTICURRENCY</h1>
    				<p class="using_text">using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model</p>
    			</div>
    		</div>
    		<div class="row front">
    			<div class="col-md-2">
    				<div class="about_img"><img src="images/img-1.png"></div>
    			</div>
    			<div class="col-md-10">
    				<h1 class="fron_text"> FRONT END MULTICURRENCY</h1>
    				<p class="using_text">using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model</p>
    			</div>
    			<div class="red_bt"><a href="#">Read More</a></div>
    		</div>
    	</div>
    </div>
	<!--about section end -->
	<!--client section start -->
    
	<!--client section end -->
	<!--footer section start -->
	<div class="footer_section layout_padding">
		<div class="container">
			<div class="row">
			    <div class="col-sm-3">
				    <div class="footer_contact">Farmer</div>
			    </div>
			    <div class="col-sm-3">
				    <div class="location_text"><img src="images/map-icon.png"><span style="padding-left: 10px;">Locations</span></div>
			    </div>
			    <div class="col-sm-3">
			    	<div class="location_text"><img src="images/call-icon.png"><span style="padding-left: 10px;">Mobile No.</span></div>
			    </div>
			    <div class="col-sm-3">
			    	<div class="location_text"><img src="images/mail-icon.png"><span style="padding-left: 10px;">E-mail</span></div>
			    </div>
		    </div>
		    <div class="enput_bt">
		    	
		    </div>
		    <div class="copyright_section">
		    	<p class="copyright_text"><a href="https://html.design"> Animal Recognition</p>
		    </div>
		</div>
	</div>
	<!--footer section end -->

      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <!-- javascript --> 
      <script src="js/owl.carousel.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         </script>	


         <script>
      // This example adds a marker to indicate the position of Bondi Beach in Sydney,
      // Australia.
      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 11,
          center: {lat: 40.645037, lng: -73.880224},
          });

        var image = 'images/location_point.png';
          var beachMarker = new google.maps.Marker({
             position: {lat: 40.645037, lng: -73.880224},
             map: map,
             icon: image
          });
        }
        </script>
        <!-- google map js -->
          <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8eaHt9Dh5H57Zh0xVTqxVdBFCvFMqFjQ&callback=initMap"></script>
        <!-- end google map js -->
</body>
</html>